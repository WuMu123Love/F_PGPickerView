//
//  PGPickerEnum.h
//  PickerViewDemo
//
//  Created by fls on 2019/9/2.
//  Copyright © 2019年 piggybear. All rights reserved.
//

#import <Foundation/Foundation.h>
typedef NS_ENUM(NSUInteger, PGPickerViewCellType) {
    PGPickerViewCellTypeDefault,
    PGPickerViewCellTypeTwoItem
};
NS_ASSUME_NONNULL_BEGIN

@interface PGPickerEnum : NSObject

@end

NS_ASSUME_NONNULL_END
